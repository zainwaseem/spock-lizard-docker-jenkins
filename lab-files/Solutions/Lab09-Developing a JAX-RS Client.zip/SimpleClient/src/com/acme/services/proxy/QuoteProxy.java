package com.acme.services.proxy;

import javax.ws.rs.core.MediaType;

import org.jboss.resteasy.client.ClientRequest;

import com.acme.services.entities.QuoteRequest;
import com.acme.services.entities.QuoteResponse;

public class QuoteProxy {
	String baseURL = "http://localhost:8080/AcmeWeb/svc/quotes";

	public QuoteResponse getQuote(QuoteRequest req) throws Exception {
		ClientRequest request = new ClientRequest(baseURL);

		request.body(MediaType.APPLICATION_XML, req);
		request.accept(MediaType.APPLICATION_XML);

		QuoteResponse res = request.postTarget(QuoteResponse.class);
		return res;

	}

}
